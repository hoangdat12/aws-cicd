
cd /var/www/my-vite-project
npm install pm2 -g
pm2 start index.js

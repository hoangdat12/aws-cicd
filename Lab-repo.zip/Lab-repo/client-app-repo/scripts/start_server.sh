#!/bin/bash
pwd
cd /var/www/my-vite-project
npm start

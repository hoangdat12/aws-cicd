sudo npm install -g npm@latest
sudo npm cache clean --force
sudo npm install